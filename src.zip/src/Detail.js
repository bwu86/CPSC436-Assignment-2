import React from 'react'

export default function Detail( {time} ) {
    return (
        <div>
            <p>You added this todo at: {time}</p>
        </div>
    )
}
